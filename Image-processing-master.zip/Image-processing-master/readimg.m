%image read & write,display
%image=imread('pust_logo.png')
%imshow(image);
imwrite(image,'logo.png')